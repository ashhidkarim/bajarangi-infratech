import heroImg from "@/assets/hero-automation.jpg";
import panelImg from "@/assets/panel.jpg";
import batchingImg from "@/assets/batching-plant.jpg";
import hmiImg from "@/assets/hmi-scada.jpg";

export type CaseStudy = {
  slug: string;
  title: string;
  tag: string;
  summary: string;
  cover: string;
  problem: string;
  solution: string[];
  tech: string[];
  outcomes: { label: string; value: string }[];
  gallery: { src: string; alt: string }[];
};

const g = (order: number[]) => {
  const imgs = [batchingImg, hmiImg, panelImg, heroImg];
  return order.map((i, idx) => ({ src: imgs[i], alt: `Project image ${idx + 1}` }));
};

export const projects: CaseStudy[] = [
  {
    slug: "concrete-batching-plant-automation",
    title: "Concrete Batching Plant Automation",
    tag: "SCADA + PLC",
    summary:
      "Full automation of a concrete batching plant with recipe control, weighing accuracy, and production reporting.",
    cover: batchingImg,
    problem:
      "The plant was running on manual switchgear with inconsistent batch quality, no traceability, and frequent rework. Operators had no live visibility into aggregate/water/cement dosing, and reports were maintained by hand — making audits and dispatch reconciliation slow and error-prone.",
    solution: [
      "Designed a Siemens S7-1200 based PLC control system with load-cell weighing for aggregates, cement and water",
      "Custom SCADA with recipe management, batch sequencing, and truck-wise dispatch tracking",
      "SQL logging of every batch with material consumption, moisture correction, and operator ID",
      "Weintek HMI for operator control with live schematic view, alarms and manual override",
      "MCC + PLC panels with VFD-driven conveyors and safety interlocks",
    ],
    tech: [
      "Siemens S7-1200 PLC",
      "Weintek HMI",
      "Custom SCADA (WinCC-style)",
      "SQL Server logging",
      "VFD Drives",
      "Load cells & indicators",
    ],
    outcomes: [
      { label: "Batch accuracy", value: "±0.5%" },
      { label: "Manual entries removed", value: "100%" },
      { label: "Report generation", value: "Automatic" },
      { label: "Downtime reduced", value: "35%" },
    ],
    gallery: g([0, 2, 1]),
  },
  {
    slug: "industrial-iot-dashboard",
    title: "Industrial IoT Dashboard",
    tag: "SQL + HMI",
    summary:
      "Plant-wide dashboard aggregating live machine data, KPIs, and energy usage across multiple lines.",
    cover: hmiImg,
    problem:
      "Data was trapped inside individual PLCs and HMIs on the shop floor. Management had no consolidated view of OEE, energy consumption, or downtime causes across lines — making improvement decisions reactive and slow.",
    solution: [
      "Deployed edge gateways polling Siemens, Delta and Mitsubishi PLCs over Modbus TCP and S7",
      "Time-series store in SQL with roll-ups for shift, day and month",
      "Web-based dashboard with live KPIs, OEE, and downtime pareto",
      "Alarm push to WhatsApp/email for critical events",
      "Role-based access for operators, supervisors and management",
    ],
    tech: [
      "Industrial IoT Gateway",
      "Modbus TCP / S7 comms",
      "SQL Server",
      "Custom web dashboard",
      "Alarm notification service",
    ],
    outcomes: [
      { label: "Machines connected", value: "20+" },
      { label: "OEE visibility", value: "Real-time" },
      { label: "Downtime response", value: "-60%" },
      { label: "Report time saved", value: "8 hrs/week" },
    ],
    gallery: g([1, 3, 2]),
  },
  {
    slug: "valve-testing-machine",
    title: "Valve Testing Machine",
    tag: "LabVIEW + DAQ",
    summary:
      "LabVIEW-driven test rig for pressure, leak and endurance testing of industrial valves with automatic reporting.",
    cover: panelImg,
    problem:
      "The OEM was running valve qualification tests manually with analog gauges and paper records. Test consistency depended on the operator, and generating per-valve test certificates for customers was a full day of clerical work.",
    solution: [
      "LabVIEW-based test sequencer with hydro, pneumatic and leak modes",
      "NI DAQ for pressure, flow and displacement acquisition",
      "PLC-driven pneumatic clamping and safety interlocks",
      "PDF certificate auto-generation per test with graphs and pass/fail",
      "SQL archive keyed by valve serial number",
    ],
    tech: [
      "LabVIEW",
      "NI DAQ hardware",
      "Delta PLC",
      "Pneumatic clamping",
      "SQL Server",
      "Automated PDF reporting",
    ],
    outcomes: [
      { label: "Test cycle time", value: "-45%" },
      { label: "Certificate generation", value: "Instant" },
      { label: "Operator dependency", value: "Removed" },
      { label: "Repeatability", value: "±0.2%" },
    ],
    gallery: g([2, 0, 3]),
  },
  {
    slug: "production-monitoring-system",
    title: "Production Monitoring System",
    tag: "SCADA + SQL",
    summary:
      "Line-level production tracking with shift targets, live counts, and rejection analysis.",
    cover: hmiImg,
    problem:
      "Shift production was reported at end-of-shift with no way to intervene mid-shift. Rejection reasons were not tracked systematically, and target-vs-actual was calculated in spreadsheets a day later.",
    solution: [
      "PLC-based cycle counting on each station with rejection reason codes",
      "SCADA screens showing live target vs actual for each shift",
      "SQL data model for hourly production and defect Pareto",
      "Andon-style visual alerts when a station falls behind target",
      "Automatic end-of-shift email reports",
    ],
    tech: ["Siemens PLC", "SCADA", "SQL Server", "Andon indicators", "Auto email reports"],
    outcomes: [
      { label: "Live target tracking", value: "Every hour" },
      { label: "Defect analysis", value: "Automated" },
      { label: "Throughput improvement", value: "+18%" },
      { label: "Data entry effort", value: "Eliminated" },
    ],
    gallery: g([1, 2, 0]),
  },
  {
    slug: "sql-data-logging",
    title: "SQL Data Logging",
    tag: "PLC + SQL",
    summary:
      "High-frequency PLC data logging into SQL with query APIs for downstream analytics.",
    cover: panelImg,
    problem:
      "Process engineers needed high-resolution historical data for troubleshooting, but existing HMIs only kept a few days of trends locally. Getting a specific timestamp's process values meant coordinating a plant visit.",
    solution: [
      "Configured PLC-to-SQL logging with millisecond timestamps for critical tags",
      "Optimised schema with partitioned tables for multi-year retention",
      "REST endpoints for downstream analytics and reporting tools",
      "Automatic archival and health checks on the logging pipeline",
    ],
    tech: ["Siemens/Delta PLC", "SQL Server", "REST API layer", "Data retention jobs"],
    outcomes: [
      { label: "Log resolution", value: "100 ms" },
      { label: "History retained", value: "3+ years" },
      { label: "Query latency", value: "<200 ms" },
      { label: "Uptime", value: "99.9%" },
    ],
    gallery: g([2, 1, 3]),
  },
  {
    slug: "energy-monitoring-system",
    title: "Energy Monitoring System",
    tag: "IoT + SCADA",
    summary:
      "Section-wise energy consumption monitoring with cost allocation and anomaly alerts.",
    cover: heroImg,
    problem:
      "Total electricity bill was rising without a clear picture of which sections or machines were driving the increase. There was no way to correlate energy use with production output.",
    solution: [
      "Modbus energy meters on each feeder aggregated by a gateway",
      "SCADA dashboards showing kWh, kVA, PF and demand per section",
      "Cost allocation by department using tariff structures",
      "Anomaly detection with alerts on abnormal consumption",
      "Correlation with production output for kWh/piece KPI",
    ],
    tech: ["Energy meters (Modbus)", "IoT gateway", "SCADA", "SQL Server", "Alerting engine"],
    outcomes: [
      { label: "Energy visibility", value: "Per section" },
      { label: "Cost savings", value: "12–15%" },
      { label: "Anomalies caught", value: "Same day" },
      { label: "kWh/piece tracked", value: "Automatic" },
    ],
    gallery: g([3, 1, 2]),
  },
  {
    slug: "recipe-management-system",
    title: "Recipe Management System",
    tag: "PLC + HMI",
    summary:
      "Centralised recipe storage and version-controlled deployment to machines on the floor.",
    cover: batchingImg,
    problem:
      "Every machine on the line had its own local recipe list. Changes were made on the HMI without traceability, causing inconsistent product across machines and disputes about who changed what.",
    solution: [
      "Central recipe database with versioning and approval workflow",
      "One-click recipe deployment to selected machines",
      "HMI recipe browser with product code lookup",
      "Full audit trail: who changed, what changed, when",
      "Recipe rollback to any previous version",
    ],
    tech: ["Siemens PLC", "Weintek HMI", "SQL Server", "Recipe API service"],
    outcomes: [
      { label: "Recipe deployment", value: "One-click" },
      { label: "Version history", value: "Full audit" },
      { label: "Product consistency", value: "Restored" },
      { label: "Change disputes", value: "Eliminated" },
    ],
    gallery: g([0, 3, 1]),
  },
  {
    slug: "machine-health-monitoring",
    title: "Machine Health Monitoring",
    tag: "IoT + Analytics",
    summary:
      "Continuous machine condition monitoring with predictive alerts for maintenance planning.",
    cover: heroImg,
    problem:
      "Critical machines were maintained on a fixed calendar schedule regardless of actual condition. Unexpected breakdowns still caused hours of downtime, and planned maintenance was often unnecessary work.",
    solution: [
      "Sensor package: vibration, temperature, motor current on critical machines",
      "Edge gateway with baseline learning and threshold alerts",
      "Health dashboard showing per-machine condition indicators",
      "Predictive alerts routed to maintenance team's phones",
      "Maintenance history log tied to each machine",
    ],
    tech: [
      "Vibration & temp sensors",
      "PLC I/O",
      "IoT gateway",
      "SCADA / web dashboard",
      "Alerting engine",
    ],
    outcomes: [
      { label: "Unplanned breakdowns", value: "-55%" },
      { label: "Maintenance cost", value: "-22%" },
      { label: "Machines monitored", value: "12" },
      { label: "Alert lead time", value: "Days ahead" },
    ],
    gallery: g([3, 2, 0]),
  },
];

export const projectBySlug = (slug: string) => projects.find((p) => p.slug === slug);
